export { Home } from "./Home/Home";
export { SingleHotel } from "./SingleHotel/SingleHotel";
export { SearchResults } from "./SearchResults/SearchResults";
export { Wishlist } from "./Wishlist/Wishlist";
export { Payment } from "./Payment/Payment";
export { OrderSummary } from "./OrderSummary/OrderSummary";