import { OrderSummaryComp } from "../../components";
import "./OrderSummary.css";
export const OrderSummary = () => {

  return (
    <main className="order-summary-main">
      <OrderSummaryComp />
    </main>
  );
};
